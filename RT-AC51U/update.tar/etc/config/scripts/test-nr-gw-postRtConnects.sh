#!/bin/sh
H=$(hostname)

D="{\"log\":{\"user_mac\":\"00:00:00:00:00:00\",\"router_serial\":\"KAIWDV000912\",\"message\":\"Перезагрузка роутера 2 $H\"}}"
echo $D

curl -XPOST \
-H "Content-type:application/json" \
-H "x-auth-token:PTzQlEIYZVslkOyzKh41cJCfJCSuhJJ8" \
-H "x-post-geturl:https://nr-clients.dev.ukrgasaws.com/" \
-H "x-post-pathto:common/logger/" \
-H "x-post-method:rt_connects" \
-d "$D" \
https://nr-gateway.dev.ukrgasaws.com/9118aabf34299ead9f57921edb7c8209/ 2>/dev/null
